package castudy.Commons;

public class NameException extends Exception {
    public NameException(){
        super("Tên Khách hàng phải in hoa ký tự đầu tiên trong mỗi từ ");
    }
}
